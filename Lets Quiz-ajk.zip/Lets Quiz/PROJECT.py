from   tkinter import *
import sample  as  s
from PIL import Image,ImageTk
import random

DS_questions        =  s.DS_questions()                   # FOR IMPORTING QUESTIONS
DS_answers_choice   =  s.DS_options()
DS_answers          =  s.DS_correct_answers()

MASE_questions        =  s.MASE_questions()
MASE_answers_choice   =  s.MASE_options()
MASE_answers          =  s.MASE_correct_answers()
 
AE_questions       =  s.AE_questions()
AE_answers_choice  =  s.AE_options()
AE_answers         =  s.AE_correct_answers()

repeations  =  10
user_answer =  []
indexes     =  []
wrong       =  []
repeations = 4

def wrong_ans():
    global wrong , labelimage , labelresulttext , labshow , wrong_btn ,labshow_re
    global  question_select   , answers_choice_select , answer_select     
    labelimage.destroy() , labelresulttext.destroy() , labshow.destroy() , wrong_btn.destroy() ,labshow_re.destroy()
     
    temp = Label(bg="orange")
    lbl_Rules = Label(root,text = "Only questions for which you have given wrong answers are displayed along with their correct answers ..",font = ("Helvetica", 14, "bold italic"),bg = "#000000",foreground = "#FACA2F",)
    lbl_Rules.pack(pady=(35,0)) 
    scrollbar = Scrollbar(root)
    scrollbar.pack(side=RIGHT, fill=Y)
    textbox = Listbox(root, bd=5, font = ("Helvetica", 14, "bold italic"),height=500,yscrollcommand=scrollbar.set)
    temp.pack(pady = (15,20))
    
    
    for e in wrong :
        text  =  question_select[e]
        text_ =  "Question    :    " + text
        textbox.insert(END,text_)
        x = answer_select[e] 
        text1  =  answers_choice_select[e][x]
        text2  =  "Answer      :     " + str(text1
                                             )
        textbox.insert(END, text2)
    textbox.pack(fill=BOTH,expand=1)
    scrollbar.config()
    
def showresult(score):     # TO CALCULATE AND DISPLAY SCORE
    global repeations ,wrong_btn , labelresulttext , labshow , labelimage ,labshow_re
    lblQuestion.destroy() , r1.destroy() ,  r2.destroy() , r3.destroy() ,  r4.destroy() , save_btn.destroy()
    
    labelimage = Label(root,background = "orange",border = 0)
    labelimage.pack(pady=(50,30))
    labelresulttext = Label(root,font = ("Consolas",20), background = "orange")
    labelresulttext.pack()
    if score >= ((repeations-1)*5):
        img = PhotoImage(file="great.png")
        labelimage.configure(image=img)
        labelimage.image = img
        labelresulttext.configure(text="You Are Excellent !!")
    elif (score >= (repeations-3)*5 and score < (repeations-1)*5):
        img = PhotoImage(file="ok.png")
        labelimage.configure(image=img)
        labelimage.image = img
        labelresulttext.configure(text="You Can Be Better !!")
    else:
        img = PhotoImage(file="bad.png")
        labelimage.configure(image=img)
        labelimage.image = img
        labelresulttext.configure(text="You Should Work Hard !!")
   
    labshow = Label(text="Your score is ",bg="lightgreen",font=("Consolas",14),justify = "center")
    labshow.pack(pady=(10,10))
    labshow_re = Label(text=score,bg="lightgreen",font=("Consolas",14),justify = "center")
    labshow_re.pack(pady=(10,10))
    
    wrong_btn.configure(text="MY WRONG ANSWERS",font=("times",14),command=wrong_ans,justify="center",bg="light green",fg="dark red")
    wrong_btn.pack(pady=(10,0))

def calc():
    global indexes , user_answer ,wrong , answer_select
    x      =  0
    score  =  0
    for k in indexes:
        print(user_answer[x],answer_select[k])
        if (user_answer[x] == answer_select[k]):
            score += 5
        else :
            score -= 1
            wrong.append(k)
        x += 1
    showresult(score)

ques = 1                          # TO CREATE FOUR OPTIONS AND ONLY CHANGING THEM FOR EACH QUESTIONS
def selected():
    global radiovar , user_answer , repeations , save_btn
    global lblQuestion , r1 , r2 , r3 , r4 , ques , answers_choice_select 
    x = radiovar.get()
    user_answer.append(x)
    radiovar.set(-1)  
        
    if ques < repeations:
        lblQuestion.config(text= question_select[indexes[ques]])
        r1['text'] = answers_choice_select[indexes[ques]][0]
        r2['text'] = answers_choice_select[indexes[ques]][1]
        r3['text'] = answers_choice_select[indexes[ques]][2]
        r4['text'] = answers_choice_select[indexes[ques]][3]
        ques += 1
        if (ques==repeations):
            save_btn.configure(text="SUBMIT TEST")
    else:
        calc()
    

def startquiz():
    global lblQuestion,r1,r2,r3,r4,save_btn  , question_select , answers_choice_select , answer_select , indexes 
    
    lblQuestion = Label(root,font = ("Consolas", 17,"bold"),width = 500, justify = "center", wraplength = 400,bg = "grey",
    text  =  question_select[indexes[0]])
    lblQuestion.pack(pady=(100,30))

    global radiovar
    radiovar = IntVar()
    radiovar.set(-1)

    r1 = Radiobutton(root,text = answers_choice_select[indexes[0]][0],font = ( "Times", 14), value = 0, variable = radiovar,bg = "lightyellow",)
    r1.pack(pady=5)
    
    r2 = Radiobutton(root,text = answers_choice_select[indexes[0]][1],font = ("Times", 14), value = 1, variable = radiovar,bg = "lightyellow", )
    r2.pack(pady=5)

    r3 = Radiobutton(root,text = answers_choice_select[indexes[0]][2],font = ("Times", 14), value = 2, variable = radiovar,bg = "lightyellow",)
    r3.pack(pady=5)

    r4 = Radiobutton(root,text = answers_choice_select[indexes[0]][3],font = ("Times", 14), value = 3, variable = radiovar,bg = "lightyellow",)
    r4.pack(pady=5)
    save_btn.configure(text="SAVE AND NEXT",font=("times",14),command=selected,justify="center",bg="light green",fg="dark red")
    save_btn.pack(pady=(50,0))

def gen(value_random):# TO GENERATE QUESTION NO.S RANDOMLY  
    global question_select , answers_choice_select , answer_select , indexes , repeations , cp_questions , gk_questions , bio_questions
    global gk_answers , cp_answers_choice,bio_answers,cp_answers,gk_answers_choice,bio_answers_choice
    i = 0
    
    if (value_random==0):
        question_select       =   DS_questions
        answers_choice_select =   DS_answers_choice
        answer_select         =   DS_answers
    elif (value_random==1):
        question_select       =   AE_questions
        answers_choice_select =   AE_answers_choice
        answer_select         =   AE_answers
    elif (value_random==2) :
        question_select       =   MASE_questions
        answers_choice_select =   MASE_answers_choice
        answer_select         =   MASE_answers
        
    generate                  =   len(question_select)
    while   (i < repeations)  : 
        x = random.randint(0,generate-2)
        if x not in indexes  :   #  QUESTIONS SHOULD NOT GET REPEAT
            indexes.append(x)
        else :
            i -= 1
        i += 1
    startquiz()    


def start(value):
    button0.destroy(), button1.destroy(), button2.destroy(), button3.destroy(), button01.destroy(), button11.destroy(), button21.destroy(), button31.destroy() 
    back_button.destroy() ,labeltext1.destroy() ,labeltext.destroy()
    gen(value)
    
def start_button1():
    labelimage.destroy(), lblInstruction.destroy(),  labeltext.destroy(), lblRules.destroy(), back_button.destroy() ,btnStart.destroy()
 
    labeltext1.configure(text="SELECT YOUR CHOICE OF DOMAIN",fg="green",font = ("Comic sans MS",24,"bold"),bg = "white")
    labeltext1.pack(pady=(100,80))
    button01.configure(text="DATA SCIENCE", font=("Helvetica", 19, "bold italic"), width=44,
                       command=lambda: start(0))
    button11.configure(text="APPLIED ELECTRONICS", font=("Helvetica", 18, "bold italic"), width=44, command=lambda: start(1))
    button21.configure(text="MECHANICAL AND SYSTEM ENGENEERING ", font=("Helvetica", 18, "bold italic"), width=44,
                       command=lambda: start(2))
    button31.configure(text="ENTRANCE EXAM", font=("Helvetica", 18, "bold italic"), width=44, state=DISABLED)
    button01.pack()
    button11.pack(pady=(20,0))
    button21.pack(pady=(20,0))
    button31.pack(pady=(20,0))
    
def future():
    labeltext.configure(text="SORRY FOR INCONVENIENCE \n\n\n THIS SECTION ISN'T REDAY NOW ",font=("Comic sans MS",18,"bold"))
    button0.destroy(), button1.destroy(), button2.destroy(),button3.destroy()
    back_button.configure(text="GO BACK",font=("Comic sans MS",16),bg="light blue", command=start_button1)
    back_button.pack(pady=(10,10))


def start_button():                                                   # AS SOON AS CLICK START COMMAND COMES HERE AND CLEAR THE BASIC WINDOW
    labelimage.destroy(),lblInstruction.destroy(),lblRules.destroy(), btnStart.destroy()
    
    labeltext.configure(text="SELECT YOUR CHOICE OF DOMAIN",fg="green")
    labeltext.pack(pady=(100,80))
    button0.configure(text="DATA SCIENCE",font=("Helvetica", 19, "bold italic"),width=44,command=lambda:start(0))
    button1.configure(text="APPLIED ELECTRONICS",font=("Helvetica", 18, "bold italic"),width=44,command=lambda:start(1))
    button2.configure(text="MECHANICAL AND SYSTEM ENGENEERING ",font=("Helvetica", 18, "bold italic"),width=44,command=lambda:start(2))
    button3.configure(text="ENTRANCE EXAM",font=("Helvetica", 18, "bold italic"),width=44,command=future)
    button0.pack()
    button1.pack(pady=(20,0))
    button2.pack(pady=(20,0))
    button3.pack(pady=(20,0))
    
# TO CREATE A BASIC WINDOW
root = Tk()
root.title("POWERED BY VIT")
root.geometry("700x600")
root.config(background="skyblue")

button0 ,button1 ,button2 ,button3 ,button01 , button11 ,button21 ,button31   = Button() , Button(),Button(),Button(),Button(),Button(),Button(),Button()
labeltext1 = Label()
back_button , save_btn , wrong_btn = Button(), Button() , Button()

img1 = PhotoImage(file="transparentGradHat.png")
labelimage = Label(root,image = img1,bg = "black")
labelimage.pack(pady=(40,0))

labeltext = Label(root,text = "LET'S START THE QUIZZZZZZZ ",font = ("Comic sans MS",24,"bold"),bg = "orange")
labeltext.pack(pady=(0,50))

img2 = PhotoImage(file="Frame.png")
btnStart = Button(root,image = img2,relief = FLAT,border = 0,command = start_button)
btnStart.pack()

lblInstruction = Label(root,text = "  Read The Rules And\n  Click Start Once You Are ready",bg = "red",font = ("Consolas",18,"bold"),justify = "center",)
lblInstruction.pack(pady=(40,70))
lblRules = Label(root,text = "This quiz contains multiple choice questions\nYou will get +5 marks for correct while -1 for incorrect answer \n Select a radio button and press 'SAVE AND NEXT ' to save your answer and proceed.\n Once you go for next questions you can not come back for previous ques.",width = 100,font = ("Times",14),bg = "#000000",foreground = "white")
lblRules.pack()

root.mainloop()



