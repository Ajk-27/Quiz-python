def DS_questions():
    que1=[
        " Which of the following is the top most important thing in data science?",
        "Which of the following approach should be used if you can’t fix the variable?",
        "Which of the following is the most important language for Data Science?",
        "Raw data should be processed only one time.",
        " Which of the following is performed by Data Scientist?",
    ]

    return que1

def MASE_questions():
    que2=[
        " Which of the following processes is used for surface finishing?",
        "What are the factors affecting selection of casting process?",
        "What are bulk loads?",
        "Which cutting condition affects the cutting temperature predominantly? ",
        "Which of the following is not a hoisting equipment with lifting gear?",

    ]

    return que2

def AE_questions() :
    que3=[
        "In transistor,the emitter current is ",
        "A simple diode can be used as",
        "Which of the following acts as a buffer?",
        "In an NPN silicon transistor, α=0.995, IE=10mA and leakage current ICBO=0.5µA. Determine ICEO?",
        "The PN sequence length is",
    ]

    return que3

def DS_options() :
    que4=[
        ["answer","question","data","none of the above"],
        ["randomize it"," non stratify it","generalize it","none of the mentioned"],
        ["Java","Ruby","R","None of the above"],
        ["True","False" ,"Can't say","None of the above"],
        [" Define the question","Create reproducible code","Challenge results", "All of the mentioned"]

    ]

    return que4
def MASE_options() :
    que5=[
        [" Shaping","Broaching","Lapping","All of the above"],
        ["Tolerances","Surface finish","Both a. and b.","None of the above"],
        ["Lump of material" ,"Single rigid mass","Homogeneous particles", "Heterogeneous particles"],
        [" depth of cut","cutting speed","feed","none of the above has any effect on cutting temperature"],
        ["Cage elevators","Jib cranes"," Pulleys","Troughed belts"]

    ]

    return que5
def AE_options() :
    que6=[
        ["slightly more than collector ","slightly less than collector","equal to the collector","equal to base current"],
        ["rectifier","modulator","amplifier","oscilator"],
        ["CC amplifier", "CE amplifier", "CB amplifier", "cascaded amplifier"],
        ["10µA","100µA","90µA","50µA"],
        [10,12,15,18]

    ]

    return que6
def MASE_correct_answers() :
    que7=[
        2,
        2,
        1,
        1,
        3

       ]

    return que7


def AE_correct_answers():
    que8 = [
        1,
        0,
        0,
        1,
        2

    ]

    return que8


def DS_correct_answers():
    que9 = [
        1,
        0,
        2,
        1,
        3

    ]

    return que9